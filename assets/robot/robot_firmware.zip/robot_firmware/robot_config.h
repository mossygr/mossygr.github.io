// =====================================================================
//  robot_config.h  –  ΟΛΕΣ οι ρυθμίσεις του ρομπότ σε ένα σημείο
//  Robot v1.5 · ESP32-CAM (AI-Thinker) · L298N · DFPlayer Pro (ηχείο απευθείας)
// =====================================================================
#ifndef ROBOT_CONFIG_H
#define ROBOT_CONFIG_H
#include <Arduino.h>

// ---------------- Wi-Fi ----------------
// Προεπιλογή: το ρομπότ φτιάχνει δικό του δίκτυο (Access Point).
// Συνδέεις το κινητό στο "Robot-4WD" και ανοίγεις http://192.168.4.1
#define AP_SSID        "Robot-4WD"
#define AP_PASSWORD    "robot1234"     // τουλάχιστον 8 χαρακτήρες
#define AP_CHANNEL     6

// Προαιρετικά: σύνδεση στο Wi-Fi του σπιτιού (STA). Άφησέ το κενό ("")
// για να μένει πάντα σε AP. Αν η σύνδεση αποτύχει, γυρίζει σε AP.
#define STA_SSID       ""
#define STA_PASSWORD   ""
#define STA_TIMEOUT_MS 20000

#define HOSTNAME       "robot4wd"

// ---------------- OTA (αναβάθμιση μέσω Wi-Fi) ----------------
// 1 = ενεργό. ΠΡΕΠΕΙ από το ΠΡΩΤΟ upload (με USB) να έχεις διαλέξει
// Tools → Partition Scheme → "Minimal SPIFFS (1.9MB APP with OTA/128KB SPIFFS)".
// Με το προεπιλεγμένο "Huge APP" δεν υπάρχει χώρος OTA: το firmware το εντοπίζει,
// γράφει προειδοποίηση στο Serial και απλώς δεν ενεργοποιεί το OTA.
#define ENABLE_OTA     1
#define OTA_PASSWORD   "robot1234"

// ---------------- Μοτέρ (L298N, jumpers ENA/ENB στη θέση τους) ----------------
// Αριστερά μοτέρ: OUT1/OUT2 ← IN1/IN2.  Δεξιά μοτέρ: OUT3/OUT4 ← IN3/IN4.
#define PIN_IN1        14   // μπλε    – αριστερά, "μπροστά"
#define PIN_IN2        15   // γαλάζιο – αριστερά, "πίσω"
#define PIN_IN3        13   // κίτρινο – δεξιά, "μπροστά"
#define PIN_IN4        12   // λευκό   – δεξιά, "πίσω"  (strapping pin! βλ. σημειώσεις)

// Κανάλια LEDC. Η κάμερα παίρνει LEDC_TIMER_0/LEDC_CHANNEL_0 στην low-speed ομάδα
// (επιβεβαιωμένο στο esp32-camera του core 3.3.6). Τα κανάλια Arduino 0..7 ανήκουν στην
// high-speed ομάδα, άρα δεν συγκρούονται· αποφεύγουμε πάντως τα 0/1 για σιγουριά.
// Στο core 3.x ο timer επιλέγεται αυτόματα: ίδια συχνότητα/ανάλυση → κοινός timer
// (τα 4 κανάλια μοτέρ μοιράζονται έναν, το φλας στα 5 kHz παίρνει άλλον).
#define CH_IN1         2
#define CH_IN2         3
#define CH_IN3         4
#define CH_IN4         5

// 1 kHz: ο L298N (διπολικά τρανζίστορ) έχει αργή μεταγωγή, στα 20 kHz χάνει
// ροπή και ζεσταίνεται περισσότερο· στο 1 kHz τα TT μοτέρ ξεκινούν πιο εύκολα
// σε χαμηλές ταχύτητες. Μειονέκτημα: ελαφρύ σφύριγμα. Δοκίμασε 2000 αν σε ενοχλεί.
#define MOTOR_PWM_FREQ 1000
#define MOTOR_PWM_BITS 8           // 0..255

// Όρια duty (0..255). Η μπαταρία 3S δίνει 9–12.6 V, ο L298N τρώει ~2 V.
// 65 % ≈ 6–7 V μέσος όρος στα μοτέρ (είναι 3–6 V μοτέρ!).
#define MAX_DUTY       166         // ≈ 65 %
#define MIN_DUTY       77          // ≈ 30 %, κάτω από αυτό δεν ξεκινούν
#define JOY_DEADZONE   8           // % – νεκρή ζώνη joystick
#define RAMP_UP_STEP   6           // μέγιστη αύξηση duty ανά βήμα (επιτάχυνση)
#define RAMP_DOWN_STEP 20          // μέγιστη μείωση duty ανά βήμα (φρενάρισμα)
#define RAMP_PERIOD_MS 10          // βήμα ράμπας
#define FAILSAFE_MS    500         // σταματά αν δεν έρθει εντολή τόσο χρόνο

// Αν κάποια πλευρά πηγαίνει ανάποδα, άλλαξε εδώ αντί για τα καλώδια.
#define INVERT_LEFT    false
#define INVERT_RIGHT   false

// ---------------- Φως (flash LED στο GPIO4) ----------------
#define PIN_FLASH      4           // είναι και γραμμή δεδομένων της SD – δεν χρησιμοποιούμε SD
#define CH_FLASH       6
#define FLASH_PWM_FREQ 5000
#define FLASH_PWM_BITS 8
#define FLASH_DEFAULT_BRIGHTNESS 128   // 0..255 (το 255 ζεσταίνει πολύ το LED)

// ---------------- Ήχος (DFPlayer Pro, μόνο TX → RX) ----------------
#define PIN_DFP_TX     2           // πράσινο καλώδιο → DFPlayer RX
#define DFP_BAUD       115200
#define DFP_BOOT_WAIT_MS 1500      // αναμονή μετά την εκκίνηση πριν την 1η εντολή
#define DFP_CMD_GAP_MS 40          // κενό ανάμεσα σε εντολές
#define DFP_DEFAULT_VOLUME 20      // 0..30 (αν παραμορφώνει ή κάνει reset στη μέγιστη, χαμήλωσε)
#define DFP_PLAYMODE   3           // 3 = παίζει ένα και σταματά
#define TRACK_COUNT    8           // πόσα κουμπιά κομματιών δείχνει η σελίδα
// 0 = AT+PLAYNUM=n (σειρά αντιγραφής στη μνήμη)
// 1 = AT+PLAYFILE=/01.mp3, /02.mp3 … (κατά όνομα αρχείου, πιο προβλέψιμο)
#define TRACK_BY_FILENAME 0
// Ηχείο 4Ω απευθείας στα L+/L− του DFPlayer Pro (χωρίς εξωτερικό ενισχυτή).
// Ο ενσωματωμένος ενισχυτής ανοίγει σε κάθε εκκίνηση (AT+AMP=ON).
// Αν το DFPlayer αρχίζει να παίζει μόνο του σε κάθε άναμμα: βάλε 1 και αντέγραψε στη
// ρίζα του δίσκου ένα σύντομο αρχείο σιωπής με το όνομα παρακάτω (π.χ. 1 s σιωπή).
// Αντέγραψέ το ΤΕΛΕΥΤΑΙΟ: με TRACK_BY_FILENAME 0 η αρίθμηση ακολουθεί τη σειρά αντιγραφής.
#define DFP_STOP_ON_BOOT 0
#define DFP_SILENT_FILE "silence.mp3"

// ---------------- Κάμερα ----------------
#define CAM_FRAME_SIZE   FRAMESIZE_VGA   // 640x480· FRAMESIZE_QVGA για πιο ομαλή εικόνα
#define CAM_JPEG_QUALITY 12              // 10..63 (μικρότερο = καλύτερο, μεγαλύτερο αρχείο)
#define CAM_XCLK_HZ      20000000
#define CAM_VFLIP        0               // 1 αν η εικόνα βγαίνει ανάποδα
#define CAM_HMIRROR      0

// ---------------- HTTP ----------------
#define HTTP_PORT        80
#define STREAM_PORT      81

#endif // ROBOT_CONFIG_H
