// =====================================================================
//  robot_motors.h  –  Οδήγηση 4 μοτέρ (2 ανά πλευρά) μέσω L298N
//  Sign-magnitude PWM πάνω στα IN (jumpers ENA/ENB στη θέση τους):
//    μπροστά:  INa = PWM, INb = LOW
//    πίσω:     INa = LOW, INb = PWM
//  Με ράμπα (περιορισμός επιτάχυνσης) και failsafe.
// =====================================================================
#ifndef ROBOT_MOTORS_H
#define ROBOT_MOTORS_H
#include <Arduino.h>
#include "robot_config.h"

namespace motors {

// Στόχος (σε duty, προσημασμένο −MAX_DUTY..+MAX_DUTY) και τρέχουσα τιμή.
static portMUX_TYPE   s_mux = portMUX_INITIALIZER_UNLOCKED;
static int16_t        s_targetL = 0, s_targetR = 0;
static int16_t        s_curL = 0, s_curR = 0;
static uint32_t       s_lastCmdMs = 0;     // προστατεύεται από το s_mux
static uint32_t       s_lastRampMs = 0;
static bool           s_ok = false;
static volatile bool  s_locked = false;    // true κατά την OTA: αγνοούνται οι εντολές

// Πρώτο πράγμα στο setup(): κρατά τα IN χαμηλά ώστε να μη «τινάζονται» τα μοτέρ.
inline void earlySafePins() {
  const uint8_t pins[] = {PIN_IN1, PIN_IN2, PIN_IN3, PIN_IN4};
  for (uint8_t p : pins) {
    pinMode(p, OUTPUT);
    digitalWrite(p, LOW);
  }
}

inline void begin() {
  bool ok = true;
  ok &= ledcAttachChannel(PIN_IN1, MOTOR_PWM_FREQ, MOTOR_PWM_BITS, CH_IN1);
  ok &= ledcAttachChannel(PIN_IN2, MOTOR_PWM_FREQ, MOTOR_PWM_BITS, CH_IN2);
  ok &= ledcAttachChannel(PIN_IN3, MOTOR_PWM_FREQ, MOTOR_PWM_BITS, CH_IN3);
  ok &= ledcAttachChannel(PIN_IN4, MOTOR_PWM_FREQ, MOTOR_PWM_BITS, CH_IN4);
  ledcWrite(PIN_IN1, 0); ledcWrite(PIN_IN2, 0);
  ledcWrite(PIN_IN3, 0); ledcWrite(PIN_IN4, 0);
  s_ok = ok;
  if (!ok) Serial.println("[ΜΟΤΕΡ] ΣΦΑΛΜΑ: ledcAttachChannel απέτυχε");
}

// Μετατρέπει ποσοστό −100..100 σε duty με ελάχιστο εκκίνησης και μέγιστο όριο.
inline int16_t pctToDuty(int pct) {
  if (pct == 0) return 0;
  int a = abs(pct);
  if (a > 100) a = 100;
  int d = MIN_DUTY + (int)((long)(MAX_DUTY - MIN_DUTY) * a / 100);
  return pct > 0 ? d : -d;
}

// Joystick → διαφορική οδήγηση. x: −100 (αριστερά) .. 100 (δεξιά),
// y: −100 (πίσω) .. 100 (μπροστά). Καλείται από το web server.
inline void setJoystick(int x, int y) {
  x = constrain(x, -100, 100);
  y = constrain(y, -100, 100);
  // νεκρή ζώνη σε κάθε άξονα
  if (abs(x) < JOY_DEADZONE) x = 0;
  if (abs(y) < JOY_DEADZONE) y = 0;

  int l = y + x;
  int r = y - x;
  // κανονικοποίηση ώστε |l|,|r| ≤ 100 χωρίς να χαλάει η αναλογία
  int m = max(abs(l), abs(r));
  if (m > 100) {
    l = l * 100 / m;
    r = r * 100 / m;
  }
  if (INVERT_LEFT)  l = -l;
  if (INVERT_RIGHT) r = -r;

  int16_t tl = pctToDuty(l), tr = pctToDuty(r);
  if (s_locked) return;
  portENTER_CRITICAL(&s_mux);
  s_lastCmdMs = millis();          // μαζί με τους στόχους, στο ίδιο κρίσιμο τμήμα
  s_targetL = tl;
  s_targetR = tr;
  portEXIT_CRITICAL(&s_mux);
}

// Κλείδωμα (OTA): μηδενίζει αμέσως τις εξόδους και αγνοεί νέες εντολές.
inline void lockOut() {
  s_locked = true;
  portENTER_CRITICAL(&s_mux);
  s_targetL = s_targetR = 0;
  portEXIT_CRITICAL(&s_mux);
  s_curL = s_curR = 0;
  if (s_ok) {
    ledcWrite(PIN_IN1, 0); ledcWrite(PIN_IN2, 0);
    ledcWrite(PIN_IN3, 0); ledcWrite(PIN_IN4, 0);
  }
}

inline void stop() {
  portENTER_CRITICAL(&s_mux);
  s_targetL = 0;
  s_targetR = 0;
  portEXIT_CRITICAL(&s_mux);
}

// Πλησιάζει τον στόχο με όριο βήματος. Μείωση |duty| πιο γρήγορα από αύξηση.
inline int16_t rampToward(int16_t cur, int16_t tgt) {
  if (cur == tgt) return cur;
  // Αν ο στόχος είναι 0 και είμαστε ήδη κάτω από το ελάχιστο, σβήσε αμέσως.
  if (tgt == 0 && abs(cur) <= MIN_DUTY) return 0;
  bool sameSign = (cur >= 0 && tgt >= 0) || (cur <= 0 && tgt <= 0);
  bool growing = sameSign && abs(tgt) > abs(cur);
  int step = growing ? RAMP_UP_STEP : RAMP_DOWN_STEP;
  int16_t next;
  if (tgt > cur) next = (int16_t)min<int>(cur + step, tgt);
  else           next = (int16_t)max<int>(cur - step, tgt);
  // Από στάση, ξεκίνα κατευθείαν από το MIN_DUTY (κάτω από αυτό δεν γυρίζουν).
  if (cur == 0 && next != 0 && abs(next) < MIN_DUTY && abs(tgt) >= MIN_DUTY)
    next = next > 0 ? MIN_DUTY : -MIN_DUTY;
  // Κατά την αλλαγή κατεύθυνσης πέρνα από το 0 χωρίς να κάθεσαι στην «νεκρή» περιοχή.
  if (!sameSign && abs(next) < MIN_DUTY) next = 0;
  return next;
}

inline void writeSide(uint8_t pinA, uint8_t pinB, int16_t duty) {
  if (duty > 0)      { ledcWrite(pinB, 0); ledcWrite(pinA, (uint32_t)duty); }
  else if (duty < 0) { ledcWrite(pinA, 0); ledcWrite(pinB, (uint32_t)(-duty)); }
  else               { ledcWrite(pinA, 0); ledcWrite(pinB, 0); }
}

// Καλείται συνέχεια από το loop().
inline void update() {
  if (!s_ok) return;
  uint32_t now = millis();
  if (now - s_lastRampMs < RAMP_PERIOD_MS) return;
  s_lastRampMs = now;

  int16_t tl, tr;
  portENTER_CRITICAL(&s_mux);
  // Failsafe: καμία εντολή για FAILSAFE_MS → στόπ. Χρόνος και στόχοι διαβάζονται μαζί,
  // και η διαφορά είναι προσημασμένη ώστε μια νεότερη χρονοσφραγίδα να μη δίνει υπερχείλιση.
  if ((int32_t)(millis() - s_lastCmdMs) > (int32_t)FAILSAFE_MS) {
    s_targetL = 0;
    s_targetR = 0;
  }
  tl = s_targetL;
  tr = s_targetR;
  portEXIT_CRITICAL(&s_mux);

  int16_t nl = rampToward(s_curL, tl);
  int16_t nr = rampToward(s_curR, tr);
  if (nl != s_curL) { s_curL = nl; writeSide(PIN_IN1, PIN_IN2, s_curL); }
  if (nr != s_curR) { s_curR = nr; writeSide(PIN_IN3, PIN_IN4, s_curR); }
}

inline int16_t currentLeft()  { return s_curL; }
inline int16_t currentRight() { return s_curR; }

}  // namespace motors

#endif // ROBOT_MOTORS_H
