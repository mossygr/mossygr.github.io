// =====================================================================
//  robot_web.h  –  Δύο esp_http_server:
//    θύρα 80 : σελίδα "/", WebSocket "/ws", εφεδρικά "/control", "/cmd", "/status"
//    θύρα 81 : MJPEG "/stream" (ξεχωριστό server ώστε η ροή να μη μπλοκάρει τον έλεγχο)
// =====================================================================
#ifndef ROBOT_WEB_H
#define ROBOT_WEB_H
#include <Arduino.h>
#include "esp_http_server.h"
#include "esp_camera.h"
#include "robot_config.h"
#include "robot_motors.h"
#include "robot_audio.h"
#include "robot_web_ui.h"

// Κατάσταση φωτός: γράφεται από το server, εφαρμόζεται στο loop().
namespace light {
static volatile bool    on = false;
static volatile uint8_t brightness = FLASH_DEFAULT_BRIGHTNESS;
static volatile bool    dirty = true;
inline void begin() {
  if (!ledcAttachChannel(PIN_FLASH, FLASH_PWM_FREQ, FLASH_PWM_BITS, CH_FLASH))
    Serial.println("[ΦΩΣ] ΣΦΑΛΜΑ: ledcAttachChannel");
  ledcWrite(PIN_FLASH, 0);
}
inline void update() {
  if (!dirty) return;
  dirty = false;
  ledcWrite(PIN_FLASH, on ? brightness : 0);
}
inline void set(bool v) { on = v; dirty = true; }
inline void setBrightness(int b) { brightness = (uint8_t)constrain(b, 0, 255); dirty = true; }
}  // namespace light

namespace web {

static httpd_handle_t s_ctrl = nullptr;
static httpd_handle_t s_stream = nullptr;
static volatile uint32_t s_frames = 0;
static volatile bool s_streamAbort = false;  // true = η ροή τερματίζεται (π.χ. OTA)     // πόσα καρέ έχουν σταλεί (όλοι οι πελάτες)

// ---------- κοινή επεξεργασία εντολών (WS και HTTP) ----------
// Επιστρέφει true αν η εντολή αναγνωρίστηκε.
// Ασφαλής ανάγνωση ακεραίου (strtol + έλεγχος ορίων). Προχωρά τον δείκτη p.
static bool readInt(const char *&p, long lo, long hi, int *out) {
  char *end = nullptr;
  long v = strtol(p, &end, 10);
  if (end == p || v < lo || v > hi) return false;
  *out = (int)v;
  p = end;
  return true;
}

inline bool handleCommand(const char *msg) {
  int a = 0, b = 0;
  const char *p = msg + 2;               // μετά το "X,"
  if (msg[0] && msg[0] != 'P' && msg[1] != ',') return false;
  switch (msg[0]) {
    case 'J':
      if (readInt(p, -1000, 1000, &a) && *p++ == ',' && readInt(p, -1000, 1000, &b)) {
        motors::setJoystick(a, b);
        return true;
      }
      break;
    case 'L':
      if (readInt(p, 0, 1, &a)) { light::set(a != 0); return true; }
      break;
    case 'B':
      if (readInt(p, 0, 255, &a)) { light::setBrightness(a); return true; }
      break;
    case 'V':
      if (readInt(p, 0, 30, &a)) { audio::setVolume(a); return true; }
      break;
    case 'T':
      if (readInt(p, 1, 999, &a)) { audio::playTrack(a); return true; }
      break;
    case 'A':
      if (!strcmp(msg, "A,pp"))   { audio::playPause(); return true; }
      if (!strcmp(msg, "A,next")) { audio::next(); return true; }
      if (!strcmp(msg, "A,prev")) { audio::prev(); return true; }
      break;
    case 'P':
      return true;   // ping: απαντάμε με κατάσταση
  }
  return false;
}

inline int stateJson(char *buf, size_t n) {
  // f = μετρητής καρέ κάμερας: η σελίδα τον χρησιμοποιεί για να καταλάβει «πάγωμα» εικόνας
  return snprintf(buf, n, "{\"v\":%d,\"l\":%d,\"b\":%d,\"ml\":%d,\"mr\":%d,\"f\":%lu}",
                  audio::volume(), light::on ? 1 : 0, (int)light::brightness,
                  motors::currentLeft(), motors::currentRight(), (unsigned long)s_frames);
}

// ---------- "/" ----------
static esp_err_t indexHandler(httpd_req_t *req) {
  httpd_resp_set_type(req, "text/html; charset=utf-8");
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");
  // Η σελίδα έχει το σημάδι %TRACKS% – το αντικαθιστούμε με TRACK_COUNT.
  const char *page = INDEX_HTML;
  const char *mark = strstr(page, "%TRACKS%");
  if (!mark) return httpd_resp_send(req, page, HTTPD_RESP_USE_STRLEN);
  httpd_resp_send_chunk(req, page, mark - page);
  char num[8];
  int len = snprintf(num, sizeof(num), "%d", TRACK_COUNT);
  httpd_resp_send_chunk(req, num, len);
  const char *rest = mark + strlen("%TRACKS%");
  httpd_resp_send_chunk(req, rest, strlen(rest));
  return httpd_resp_send_chunk(req, nullptr, 0);
}

// ---------- "/ws" WebSocket ----------
static esp_err_t wsHandler(httpd_req_t *req) {
  if (req->method == HTTP_GET) {
    Serial.println("[WEB] WebSocket συνδέθηκε");
    return ESP_OK;   // handshake
  }
  httpd_ws_frame_t f = {};
  f.type = HTTPD_WS_TYPE_TEXT;
  esp_err_t r = httpd_ws_recv_frame(req, &f, 0);   // μόνο το μήκος
  if (r != ESP_OK) return r;
  // Τα δικά μας μηνύματα είναι < 64 bytes. Μεγαλύτερο πλαίσιο = άγνωστος πελάτης:
  // ESP_FAIL κλείνει τη σύνδεση (αλλιώς τα αδιάβαστα bytes θα χάλαγαν το επόμενο πλαίσιο).
  if (f.len > 63) return ESP_FAIL;
  if (f.len == 0) return ESP_OK;
  uint8_t buf[64];
  f.payload = buf;
  r = httpd_ws_recv_frame(req, &f, f.len);
  if (r != ESP_OK) return r;
  buf[f.len] = 0;
  if (f.type != HTTPD_WS_TYPE_TEXT) return ESP_OK;

  handleCommand((const char *)buf);
  // Απάντηση κατάστασης μόνο στο ping (για να μη γεμίζει η γραμμή στα 20 Hz).
  if (buf[0] == 'P') {
    char js[96];
    int n = stateJson(js, sizeof(js));
    httpd_ws_frame_t out = {};
    out.type = HTTPD_WS_TYPE_TEXT;
    out.payload = (uint8_t *)js;
    out.len = n;
    httpd_ws_send_frame(req, &out);
  }
  return ESP_OK;
}

// ---------- εφεδρικό HTTP ----------
static esp_err_t sendState(httpd_req_t *req) {
  char js[96];
  int n = stateJson(js, sizeof(js));
  httpd_resp_set_type(req, "application/json");
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");
  return httpd_resp_send(req, js, n);
}

static bool queryInt(httpd_req_t *req, const char *key, int *out) {
  char q[96], v[16];
  if (httpd_req_get_url_query_str(req, q, sizeof(q)) != ESP_OK) return false;
  if (httpd_query_key_value(q, key, v, sizeof(v)) != ESP_OK) return false;
  *out = atoi(v);
  return true;
}

static esp_err_t controlHandler(httpd_req_t *req) {   // /control?x=&y=
  int x = 0, y = 0;
  if (queryInt(req, "x", &x) && queryInt(req, "y", &y)) motors::setJoystick(x, y);
  return sendState(req);
}

static esp_err_t cmdHandler(httpd_req_t *req) {       // /cmd?c=L,1
  char q[96], c[48];
  if (httpd_req_get_url_query_str(req, q, sizeof(q)) == ESP_OK &&
      httpd_query_key_value(q, "c", c, sizeof(c)) == ESP_OK) {
    // αποκωδικοποίηση %2C → ','
    char d[48]; size_t j = 0;
    for (size_t i = 0; c[i] && j < sizeof(d) - 1; i++) {
      if (c[i] == '%' && c[i + 1] && c[i + 2]) {
        char h[3] = {c[i + 1], c[i + 2], 0};
        d[j++] = (char)strtol(h, nullptr, 16);
        i += 2;
      } else d[j++] = c[i];
    }
    d[j] = 0;
    handleCommand(d);
  }
  return sendState(req);
}

// ---------- "/stream" MJPEG ----------
#define PART_BOUNDARY "robotframe"
static const char *STREAM_CT = "multipart/x-mixed-replace;boundary=" PART_BOUNDARY;
static const char *STREAM_BOUNDARY = "\r\n--" PART_BOUNDARY "\r\n";
static const char *STREAM_PART = "Content-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n";

static esp_err_t streamHandler(httpd_req_t *req) {
  esp_err_t res = httpd_resp_set_type(req, STREAM_CT);
  if (res != ESP_OK) return res;
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");
  if (s_streamAbort) {                 // κατά την OTA δεν ξεκινά νέα ροή
    httpd_resp_set_status(req, "503 Service Unavailable");
    return httpd_resp_send(req, "OTA", 3);
  }
  char part[64];
  while (true) {
    if (s_streamAbort) { res = ESP_FAIL; break; }   // κλείνει τη σύνδεση, ελευθερώνει το task
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
      Serial.println("[ΚΑΜΕΡΑ] αποτυχία λήψης καρέ");
      res = ESP_FAIL;
      break;
    }
    s_frames = s_frames + 1;
    if (fb->format != PIXFORMAT_JPEG) {   // δεν πρέπει να συμβεί (ζητάμε JPEG)
      esp_camera_fb_return(fb);
      res = ESP_FAIL;
      break;
    }
    size_t hl = snprintf(part, sizeof(part), STREAM_PART, (unsigned)fb->len);
    res = httpd_resp_send_chunk(req, STREAM_BOUNDARY, strlen(STREAM_BOUNDARY));
    if (res == ESP_OK) res = httpd_resp_send_chunk(req, part, hl);
    if (res == ESP_OK) res = httpd_resp_send_chunk(req, (const char *)fb->buf, fb->len);
    esp_camera_fb_return(fb);
    if (res != ESP_OK) break;   // ο πελάτης έκλεισε
  }
  return res;
}

// Σταματά τη ροή κάμερας (π.χ. κατά την αναβάθμιση OTA, για να ελευθερωθεί το Wi-Fi).
// ΔΕΝ καλεί httpd_stop(): αυτό περιμένει το task του server, που μπορεί να είναι μέσα
// στο streamHandler → θα κολλούσε. Απλώς σηκώνει μια σημαία που ελέγχεται σε κάθε καρέ·
// ο handler επιστρέφει μέσα σε ένα καρέ και οι νέες αιτήσεις παίρνουν 503.
inline void stopStream() { s_streamAbort = true; }

inline void begin() {
  httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
  cfg.server_port = HTTP_PORT;
  cfg.ctrl_port = 32768;
  cfg.max_uri_handlers = 8;
  // Όριο sockets: LWIP_MAX_SOCKETS = 16. Κάθε server κρατά max_open_sockets + 3 εσωτερικά.
  // 80: 5+3, 81: 3+3 → 14, μένουν 2 για ArduinoOTA/mDNS.
  cfg.max_open_sockets = 5;
  cfg.lru_purge_enable = true;   // κλείνει παλιές συνδέσεις αν γεμίσει
  cfg.stack_size = 6144;

  httpd_uri_t uIndex   = {}; uIndex.uri = "/";        uIndex.method = HTTP_GET; uIndex.handler = indexHandler;
  httpd_uri_t uWs      = {}; uWs.uri = "/ws";         uWs.method = HTTP_GET;    uWs.handler = wsHandler; uWs.is_websocket = true;
  httpd_uri_t uControl = {}; uControl.uri = "/control"; uControl.method = HTTP_GET; uControl.handler = controlHandler;
  httpd_uri_t uCmd     = {}; uCmd.uri = "/cmd";       uCmd.method = HTTP_GET;   uCmd.handler = cmdHandler;
  httpd_uri_t uStatus  = {}; uStatus.uri = "/status"; uStatus.method = HTTP_GET; uStatus.handler = sendState;

  if (httpd_start(&s_ctrl, &cfg) == ESP_OK) {
    httpd_register_uri_handler(s_ctrl, &uIndex);
    httpd_register_uri_handler(s_ctrl, &uWs);
    httpd_register_uri_handler(s_ctrl, &uControl);
    httpd_register_uri_handler(s_ctrl, &uCmd);
    httpd_register_uri_handler(s_ctrl, &uStatus);
  } else {
    Serial.println("[WEB] ΣΦΑΛΜΑ εκκίνησης server θύρας 80");
  }

  httpd_config_t scfg = HTTPD_DEFAULT_CONFIG();
  scfg.server_port = STREAM_PORT;
  scfg.ctrl_port = 32769;
  scfg.max_open_sockets = 3;
  scfg.lru_purge_enable = true;
  // Αν το κινητό χάσει το Wi-Fi, η παλιά σύνδεση μένει «μισάνοιχτη»: με 3 s timeout
  // η ροή απελευθερώνεται γρήγορα για να ξανασυνδεθεί. Η ροή εξυπηρετεί μία συσκευή τη φορά.
  scfg.send_wait_timeout = 3;   // 3 s: αρκετό για ένα καρέ VGA σε αδύναμο σήμα
  scfg.recv_wait_timeout = 3;
  httpd_uri_t uStream = {}; uStream.uri = "/stream"; uStream.method = HTTP_GET; uStream.handler = streamHandler;
  if (httpd_start(&s_stream, &scfg) == ESP_OK) {
    httpd_register_uri_handler(s_stream, &uStream);
  } else {
    Serial.println("[WEB] ΣΦΑΛΜΑ εκκίνησης server θύρας 81");
  }
}

}  // namespace web

#endif // ROBOT_WEB_H
