// =====================================================================
//  robot_web_ui.h  –  Η σελίδα ελέγχου (ελληνικά, για κινητό), αποθηκευμένη στη flash
//  Πρωτόκολλο WebSocket /ws (κείμενο):
//    J,x,y   joystick  x,y ∈ −100..100 (στέλνεται ~20 φορές/δευτ. όσο κρατάς)
//    L,0|1   φως off/on          B,n  φωτεινότητα 0..255
//    V,n     ένταση 0..30        T,n  παίξε κομμάτι n
//    A,pp|next|prev              P    ping → απάντηση JSON κατάστασης
//  Αν το WebSocket δεν συνδεθεί, η σελίδα γυρίζει σε HTTP GET /control και /cmd.
// =====================================================================
#ifndef ROBOT_WEB_UI_H
#define ROBOT_WEB_UI_H
#include <Arduino.h>

static const char INDEX_HTML[] PROGMEM = R"rawliteral(<!doctype html>
<html lang="el"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="theme-color" content="#111418">
<title>Ρομπότ 4WD</title>
<style>
:root{--bg:#111418;--card:#1b2027;--fg:#e9edf2;--mut:#94a0b0;--acc:#f28c18;--ok:#22c55e;--bad:#ef4444;--line:#2a313b}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;background:var(--bg);color:var(--fg);font:15px/1.4 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
 -webkit-user-select:none;user-select:none;overscroll-behavior:none}
header{display:flex;align-items:center;justify-content:space-between;padding:8px 12px}
h1{font-size:1rem;margin:0;font-weight:650}
#conn{display:flex;align-items:center;gap:6px;font-size:.85rem;color:var(--mut)}
#dot{width:10px;height:10px;border-radius:50%;background:var(--bad);box-shadow:0 0 0 3px #ef444433}
#dot.on{background:var(--ok);box-shadow:0 0 0 3px #22c55e33}
#cam{position:relative;background:#000;aspect-ratio:4/3;max-height:52vh;width:100%;display:flex;align-items:center;justify-content:center;overflow:hidden}
#cam img{width:100%;height:100%;object-fit:contain;visibility:hidden}
#camMsg{position:absolute;color:var(--mut);font-size:.9rem}
main{display:grid;grid-template-columns:1fr;gap:10px;padding:10px;max-width:900px;margin:0 auto}
#drive{margin:10px auto 0;max-width:880px;width:calc(100% - 20px)}
@media (min-width:760px){main{grid-template-columns:1fr 1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px}
.card h2{font-size:.8rem;letter-spacing:.06em;text-transform:uppercase;color:var(--mut);margin:0 0 8px;font-weight:600}
#joyWrap{display:flex;flex-direction:column;align-items:center;gap:6px}
#joy{position:relative;width:min(70vw,240px);height:min(70vw,240px);border-radius:50%;
 background:radial-gradient(circle,#252c36 0,#1a1f26 70%);border:2px solid var(--line);touch-action:none}
#joy::before,#joy::after{content:"";position:absolute;background:var(--line)}
#joy::before{left:50%;top:10%;bottom:10%;width:1px}#joy::after{top:50%;left:10%;right:10%;height:1px}
#knob{position:absolute;left:50%;top:50%;width:38%;height:38%;margin:-19% 0 0 -19%;border-radius:50%;
 background:radial-gradient(circle at 35% 30%,#ffb35c,var(--acc));box-shadow:0 6px 18px #0008;z-index:2;will-change:transform}
#joyVal{font:12px ui-monospace,Menlo,monospace;color:var(--mut)}
.row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
button{font:inherit;color:var(--fg);background:#262d37;border:1px solid var(--line);border-radius:10px;padding:10px 12px;min-width:44px;min-height:44px;touch-action:manipulation}
button:active{background:#323b47}
button.on{background:var(--acc);border-color:var(--acc);color:#111}
#tracks{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:8px}
input[type=range]{flex:1;accent-color:var(--acc);height:32px}
.lbl{min-width:3.2em;text-align:right;font-variant-numeric:tabular-nums;color:var(--mut)}
small{color:var(--mut)}
#hlight{display:none;min-height:34px;min-width:44px;padding:4px 10px;margin-left:auto;margin-right:10px}
#hlight.on{background:var(--acc);border-color:var(--acc)}
/* Οριζόντιο κινητό: κάμερα αριστερά, joystick δεξιά, φως/ήχος από κάτω (κύλιση) */
@media (orientation:landscape) and (max-height:520px){
 header{padding:4px 10px}
 #wrap{display:grid;grid-template-columns:1fr minmax(240px,38vw);grid-template-rows:calc(100vh - 34px);grid-template-rows:calc(100dvh - 34px);gap:8px;padding:0 8px}
 #cam{max-height:none;height:100%;aspect-ratio:auto;border-radius:10px}
 #drive{height:100%;display:flex;align-items:center;justify-content:center;padding:8px}
 #joy{width:min(36vw,calc(100vh - 90px));height:min(36vw,calc(100vh - 90px));width:min(36vw,calc(100dvh - 90px));height:min(36vw,calc(100dvh - 90px))}
 #hlight{display:inline-flex}
 #drive h2,#drive small{display:none}
 main{grid-template-columns:1fr 1fr}
}
</style></head><body>
<header><h1>🤖 Ρομπότ 4WD</h1><button id="hlight" aria-label="Φως">💡</button><div id="conn"><span id="dot"></span><span id="connTxt">Σύνδεση…</span></div></header>
<div id="wrap">
<div id="cam"><span id="camMsg">Φόρτωση κάμερας…</span><img id="stream" alt=""></div>
 <section class="card" id="drive"><h2>Οδήγηση</h2>
  <div id="joyWrap"><div id="joy"><div id="knob"></div></div><div id="joyVal">x 0 · y 0</div>
  <small>Σπρώξε το πορτοκαλί κουμπί· όσο πιο μακριά, τόσο πιο γρήγορα.</small></div>
 </section>
</div>
<main>
 <section class="card"><h2>Φως</h2>
  <div class="row"><button id="light">💡 Φως: OFF</button>
   <input id="bright" type="range" min="10" max="255" value="128" aria-label="Φωτεινότητα"><span class="lbl" id="brightV">50%</span></div>
  <h2 style="margin-top:14px">Ήχος</h2>
  <div id="tracks"></div>
  <div class="row" style="margin-bottom:8px">
   <button data-a="prev" aria-label="Προηγούμενο">⏮</button><button data-a="pp" aria-label="Αναπαραγωγή/Παύση">⏯</button><button data-a="next" aria-label="Επόμενο">⏭</button></div>
  <div class="row"><span>🔊</span><input id="vol" type="range" min="0" max="30" value="20" aria-label="Ένταση"><span class="lbl" id="volV">20</span></div>
 </section>
</main>
<script>
(()=>{
const TRACKS=%TRACKS%;
const $=id=>document.getElementById(id);
const host=location.hostname||'192.168.4.1';
// ---------- κάμερα ----------
const img=$('stream');
function startStream(){img.src='http://'+host+':81/stream?t='+Date.now();}
img.onload=()=>{$('camMsg').style.display='none';img.style.visibility='visible'};
// Το MJPEG δεν δίνει «error» όταν απλώς σταματήσουν τα καρέ: ελέγχουμε τον μετρητή καρέ
// του server (πεδίο f στην απάντηση ping) και ξαναξεκινάμε τη ροή αν πάγωσε για ~3 s.
let lastF=-1,lastFChange=Date.now();
function checkFrames(f){if(f===undefined)return;const now=Date.now();
 if(f!==lastF){lastF=f;lastFChange=now;return;}
 if(now-lastFChange>3000&&img.style.visibility==='visible'){img.style.visibility='hidden';
  $('camMsg').style.display='';$('camMsg').textContent='Η εικόνα πάγωσε – επανασύνδεση…';lastFChange=now;startStream();}}
img.onerror=()=>{img.style.visibility='hidden';$('camMsg').style.display='';$('camMsg').textContent='Η κάμερα δεν απαντά – νέα προσπάθεια…';setTimeout(startStream,2000)};
startStream();
// ---------- σύνδεση ----------
let ws=null,wsOk=false,lastPong=0,useHttp=false,wsFails=0,httpBusy=false;
function setConn(ok){$('dot').classList.toggle('on',ok);$('connTxt').textContent=ok?(useHttp?'Συνδέθηκε (HTTP)':'Συνδέθηκε'):'Χωρίς σύνδεση';}
function connect(){
 try{ws=new WebSocket('ws://'+host+'/ws');}catch(e){wsFails++;return;}
 ws.onopen=()=>{wsOk=true;wsFails=0;useHttp=false;lastPong=Date.now();send('P');};
 ws.onclose=()=>{wsOk=false;if(++wsFails>=3)useHttp=true;setTimeout(connect,1000)};
 ws.onerror=()=>{try{ws.close()}catch(e){}};
 ws.onmessage=e=>{lastPong=Date.now();try{applyState(JSON.parse(e.data))}catch(_){}};
}
function send(m){
 if(wsOk&&ws.readyState===1){
  if(m[0]==='J'&&ws.bufferedAmount>64)return true; // γραμμή φορτωμένη: το επόμενο keep-alive στέλνει την τρέχουσα τιμή
  ws.send(m);return true;}
 if(useHttp){ // εφεδρικό HTTP
  const p=m.split(',');let u;
  if(p[0]==='J'){if(httpBusy)return true;u='/control?x='+p[1]+'&y='+p[2];httpBusy=true;}
  else u='/cmd?c='+encodeURIComponent(m);
  const isJ=p[0]==='J';
  fetch(u,{cache:'no-store'}).then(r=>r.json()).then(s=>{lastPong=Date.now();applyState(s)}).catch(()=>{})
   .finally(()=>{if(isJ)httpBusy=false;});
  return true;}
 return false;
}
setInterval(()=>{send('P');setConn(Date.now()-lastPong<2500)},1000);
connect();
let stateApplied=false;
function applyState(s){
 checkFrames(s.f);
 if(s.v!==undefined&&!volDrag){$('vol').value=s.v;$('volV').textContent=s.v;}
 if(s.l!==undefined)setLightUI(!!s.l);
 if(s.b!==undefined&&!stateApplied){$('bright').value=s.b;$('brightV').textContent=Math.round(s.b/2.55)+'%';}
 stateApplied=true;
}
// ---------- joystick (multitouch-safe: κρατά μόνο το δικό του pointer) ----------
const joy=$('joy'),knob=$('knob');let pid=null,jx=0,jy=0,lastSent='';
function joyMove(e){
 const r=joy.getBoundingClientRect(),R=r.width/2,cx=r.left+R,cy=r.top+R;
 let dx=e.clientX-cx,dy=e.clientY-cy;const lim=R*0.62,d=Math.hypot(dx,dy);
 if(d>lim){dx*=lim/d;dy*=lim/d;}
 knob.style.transform='translate('+dx+'px,'+dy+'px)';
 jx=Math.round(dx/lim*100);jy=Math.round(-dy/lim*100);
 $('joyVal').textContent='x '+jx+' · y '+jy;
}
function joyEnd(e){if(e.pointerId!==pid)return;pid=null;jx=0;jy=0;knob.style.transition='transform .12s';knob.style.transform='';
 $('joyVal').textContent='x 0 · y 0';for(let i=0;i<3;i++)setTimeout(()=>send('J,0,0'),i*60);}
joy.addEventListener('pointerdown',e=>{if(pid!==null)return;pid=e.pointerId;joy.setPointerCapture(pid);knob.style.transition='none';joyMove(e);e.preventDefault();});
joy.addEventListener('pointermove',e=>{if(e.pointerId===pid){joyMove(e);e.preventDefault();}});
joy.addEventListener('pointerup',joyEnd);joy.addEventListener('pointercancel',joyEnd);
joy.addEventListener('lostpointercapture',joyEnd);
// ~20 Hz όσο κρατάς το joystick (κρατά ζωντανό το failsafe των 500 ms)
setInterval(()=>{if(pid!==null){const m='J,'+jx+','+jy;send(m);lastSent=m;}},50);
document.addEventListener('visibilitychange',()=>{if(document.hidden){pid=null;send('J,0,0');}});
// ---------- φως ----------
let lightOn=false;
function setLightUI(on){lightOn=on;$('light').classList.toggle('on',on);$('hlight').classList.toggle('on',on);$('light').textContent='💡 Φως: '+(on?'ON':'OFF');}
$('light').onclick=$('hlight').onclick=()=>{const want=!lightOn;if(send('L,'+(want?1:0)))setLightUI(want);};
let bT=0;$('bright').oninput=e=>{const v=e.target.value;$('brightV').textContent=Math.round(v/2.55)+'%';
 clearTimeout(bT);bT=setTimeout(()=>send('B,'+v),80);};
// ---------- ήχος ----------
const tr=$('tracks');for(let i=1;i<=TRACKS;i++){const b=document.createElement('button');b.textContent='♪ '+i;b.onclick=()=>send('T,'+i);tr.appendChild(b);}
document.querySelectorAll('[data-a]').forEach(b=>b.onclick=()=>send('A,'+b.dataset.a));
let vT=0,volDrag=false;const vol=$('vol');
vol.addEventListener('pointerdown',()=>volDrag=true);vol.addEventListener('pointerup',()=>volDrag=false);
vol.oninput=e=>{const v=e.target.value;$('volV').textContent=v;clearTimeout(vT);vT=setTimeout(()=>send('V,'+v),120);};
vol.onchange=()=>{volDrag=false};
})();
</script></body></html>)rawliteral";

#endif // ROBOT_WEB_UI_H
