// =====================================================================
//  robot_audio.h  –  DFPlayer Pro (DFR0768) με εντολές AT, μόνο ESP32 TX → RX
//  Δεν υπάρχει απάντηση από τη μονάδα, άρα η ένταση «θυμάται» στο firmware.
//  Οι εντολές μπαίνουν σε ουρά και στέλνονται από το loop() με μικρό κενό,
//  ώστε το web server να μην μπλοκάρει ποτέ. Η ένταση στέλνεται «συμπτυγμένη»
//  (μόνο η τελευταία τιμή), ώστε να μη χάνεται ποτέ και να μη γεμίζει η ουρά.
// =====================================================================
#ifndef ROBOT_AUDIO_H
#define ROBOT_AUDIO_H
#include <Arduino.h>
#include "robot_config.h"

namespace audio {

static HardwareSerial &port = Serial1;
static QueueHandle_t   s_q = nullptr;
static uint32_t        s_bootMs = 0;
static uint32_t        s_lastSendMs = 0;
static volatile int    s_volume = DFP_DEFAULT_VOLUME;   // τι δείχνει η σελίδα
static int             s_volPending = DFP_DEFAULT_VOLUME; // −1 = τίποτα να σταλεί (μόνο atomic πρόσβαση)
static volatile int    s_lastTrack = 0;

struct Cmd { char text[40]; };

// Βάζει εντολή στην ουρά (ασφαλές από άλλο task). Χωρίς "\r\n".
inline bool enqueue(const char *fmt, ...) {
  if (!s_q) return false;
  Cmd c;
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(c.text, sizeof(c.text), fmt, ap);
  va_end(ap);
  bool ok = xQueueSend(s_q, &c, 0) == pdTRUE;
  if (!ok) Serial.printf("[ΗΧΟΣ] ουρά γεμάτη, χάθηκε: %s\n", c.text);
  return ok;
}

inline void begin() {
  s_q = xQueueCreate(16, sizeof(Cmd));
  // RX = -1: δεν χρησιμοποιούμε το TX του DFPlayer. Μόνο TX στο GPIO2.
  port.begin(DFP_BAUD, SERIAL_8N1, -1, PIN_DFP_TX);
  s_bootMs = millis();

  // Στέλνονται σε ΚΑΘΕ εκκίνηση: χωρίς γραμμή TX δεν μπορούμε να ξέρουμε αν η μονάδα
  // τα έλαβε (π.χ. η 1η εκκίνηση γίνεται στο γραφείο, χωρίς DFPlayer). Οι λίγες εγγραφές
  // ανά άναμμα είναι αμελητέες για τη διάρκεια ζωής της μονάδας.
  enqueue("AT+PROMPT=OFF");
  enqueue("AT+PLAYMODE=%d", DFP_PLAYMODE);
  // Το ηχείο είναι απευθείας στα L+/L− του DFPlayer: ο ενσωματωμένος ενισχυτής πρέπει να είναι ON.
  enqueue("AT+AMP=ON");
#if DFP_STOP_ON_BOOT
  // Αν η μονάδα ξεκινά να παίζει μόνη της στην εκκίνηση: παίζουμε ένα αρχείο σιωπής.
  // (Χωρίς TX δεν ξέρουμε αν παίζει, οπότε ένα «PP» θα μπορούσε να την ΞΕΚΙΝΗΣΕΙ.)
  enqueue("AT+PLAYFILE=/%s", DFP_SILENT_FILE);
#endif
  // η ένταση στέλνεται από το update() (s_volPending)
}

// Καλείται από το loop().
inline void update() {
  if (!s_q) return;
  uint32_t now = millis();
  if (now - s_bootMs < DFP_BOOT_WAIT_MS) return;
  if (now - s_lastSendMs < DFP_CMD_GAP_MS) return;
  Cmd c;
  if (xQueueReceive(s_q, &c, 0) == pdTRUE) {
    // συνηθισμένες εντολές πρώτα (π.χ. αρχικές ρυθμίσεις)
  } else {
    // ατομική ανάγνωση-και-μηδενισμός: μια νέα τιμή από το web task δεν χάνεται
    int v = __atomic_exchange_n(&s_volPending, -1, __ATOMIC_SEQ_CST);
    if (v < 0) return;
    snprintf(c.text, sizeof(c.text), "AT+VOL=%d", v);
  }
  port.print(c.text);
  port.print("\r\n");
  s_lastSendMs = now;
  Serial.printf("[ΗΧΟΣ] → %s\n", c.text);
}

inline void setVolume(int v) {
  v = constrain(v, 0, 30);
  s_volume = v;
  __atomic_store_n(&s_volPending, v, __ATOMIC_SEQ_CST);  // στέλνεται η τελευταία τιμή
}
inline int volume() { return s_volume; }

inline void playTrack(int n) {
  if (n < 1) return;
  s_lastTrack = n;
#if TRACK_BY_FILENAME
  enqueue("AT+PLAYFILE=/%02d.mp3", n);
#else
  enqueue("AT+PLAYNUM=%d", n);
#endif
}
inline void playPause() { enqueue("AT+PLAY=PP"); }
inline void next()      { enqueue("AT+PLAY=NEXT"); }
inline void prev()      { enqueue("AT+PLAY=LAST"); }

}  // namespace audio

#endif // ROBOT_AUDIO_H
