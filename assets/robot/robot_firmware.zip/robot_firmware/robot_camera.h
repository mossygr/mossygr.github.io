// =====================================================================
//  robot_camera.h  –  OV2640 στην AI-Thinker ESP32-CAM
// =====================================================================
#ifndef ROBOT_CAMERA_H
#define ROBOT_CAMERA_H
#include <Arduino.h>
#include "esp_camera.h"
#include "robot_config.h"

// Ακροδέκτες AI-Thinker (από το σχηματικό ESP32_CAM_V1.6)
#define CAM_PIN_PWDN   32
#define CAM_PIN_RESET  -1
#define CAM_PIN_XCLK    0
#define CAM_PIN_SIOD   26
#define CAM_PIN_SIOC   27
#define CAM_PIN_D7     35
#define CAM_PIN_D6     34
#define CAM_PIN_D5     39
#define CAM_PIN_D4     36
#define CAM_PIN_D3     21
#define CAM_PIN_D2     19
#define CAM_PIN_D1     18
#define CAM_PIN_D0      5
#define CAM_PIN_VSYNC  25
#define CAM_PIN_HREF   23
#define CAM_PIN_PCLK   22

namespace camera {

inline bool begin() {
  camera_config_t c = {};
  c.pin_pwdn     = CAM_PIN_PWDN;
  c.pin_reset    = CAM_PIN_RESET;
  c.pin_xclk     = CAM_PIN_XCLK;
  c.pin_sccb_sda = CAM_PIN_SIOD;
  c.pin_sccb_scl = CAM_PIN_SIOC;
  c.pin_d7 = CAM_PIN_D7; c.pin_d6 = CAM_PIN_D6; c.pin_d5 = CAM_PIN_D5; c.pin_d4 = CAM_PIN_D4;
  c.pin_d3 = CAM_PIN_D3; c.pin_d2 = CAM_PIN_D2; c.pin_d1 = CAM_PIN_D1; c.pin_d0 = CAM_PIN_D0;
  c.pin_vsync = CAM_PIN_VSYNC;
  c.pin_href  = CAM_PIN_HREF;
  c.pin_pclk  = CAM_PIN_PCLK;
  c.xclk_freq_hz = CAM_XCLK_HZ;
  // Η κάμερα χρησιμοποιεί LEDC_TIMER_0 / LEDC_CHANNEL_0 (low-speed ομάδα).
  // Τα κανάλια 2..6 του Arduino ανήκουν στην high-speed ομάδα → καμία σύγκρουση.
  c.ledc_timer   = LEDC_TIMER_0;
  c.ledc_channel = LEDC_CHANNEL_0;
  c.pixel_format = PIXFORMAT_JPEG;
  c.grab_mode    = CAMERA_GRAB_LATEST;   // πάντα το πιο φρέσκο καρέ (λιγότερη καθυστέρηση)

  if (psramFound()) {
    c.frame_size   = CAM_FRAME_SIZE;
    c.jpeg_quality = CAM_JPEG_QUALITY;
    c.fb_count     = 2;
    c.fb_location  = CAMERA_FB_IN_PSRAM;
  } else {
    Serial.println("[ΚΑΜΕΡΑ] Δεν βρέθηκε PSRAM – έλεγξε ότι η πλακέτα είναι \"AI Thinker ESP32-CAM\"");
    c.frame_size   = FRAMESIZE_QVGA;
    c.jpeg_quality = 15;
    c.fb_count     = 1;
    c.fb_location  = CAMERA_FB_IN_DRAM;
    c.grab_mode    = CAMERA_GRAB_WHEN_EMPTY;
  }

  esp_err_t err = esp_camera_init(&c);
  if (err != ESP_OK) {
    Serial.printf("[ΚΑΜΕΡΑ] ΣΦΑΛΜΑ esp_camera_init 0x%x\n", err);
    return false;
  }
  sensor_t *s = esp_camera_sensor_get();
  if (s) {
    s->set_vflip(s, CAM_VFLIP);
    s->set_hmirror(s, CAM_HMIRROR);
  }
  return true;
}

}  // namespace camera

#endif // ROBOT_CAMERA_H
