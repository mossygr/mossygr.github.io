// =====================================================================
//  Ρομπότ 4WD v1.5 – firmware για ESP32-CAM (AI-Thinker)
//
//  Arduino IDE · ESP32 Arduino core 3.x
//  Tools → Board: "AI Thinker ESP32-CAM"  (ορίζει μόνο του BOARD_HAS_PSRAM)
//          Partition Scheme: "Minimal SPIFFS (1.9MB APP with OTA/128KB SPIFFS)"
//            ← ΑΠΟ ΤΟ ΠΡΩΤΟ upload, αλλιώς οι αναβαθμίσεις μέσω Wi-Fi (OTA) δεν
//              δουλεύουν και θα χρειαστεί ξανά η βάση MB για να αλλάξεις partition.
//          Upload Speed: 115200 αν το upload σταματά στη μέση (CH340).
//
//  Λειτουργίες: ζωντανή κάμερα (θύρα 81 /stream), σελίδα ελέγχου (θύρα 80),
//  joystick αναλογικής ταχύτητας μέσω WebSocket, φως (flash LED GPIO4),
//  ήχος/ένταση μέσω DFPlayer Pro (εντολές AT στο GPIO2).
//  Όλες οι ρυθμίσεις βρίσκονται στο robot_config.h.
// =====================================================================
#include <Arduino.h>
#include <WiFi.h>
#include "robot_config.h"
#include "robot_motors.h"
#include "robot_audio.h"
#include "robot_camera.h"
#include "robot_web.h"
#if ENABLE_OTA
#include <ArduinoOTA.h>
#include "esp_ota_ops.h"
#endif

static bool s_otaReady = false;

static void startWifi() {
  WiFi.persistent(false);
  bool sta = false;
  if (strlen(STA_SSID) > 0) {
    Serial.printf("[WIFI] Σύνδεση στο \"%s\"…\n", STA_SSID);
    WiFi.mode(WIFI_STA);
    WiFi.setHostname(HOSTNAME);
    WiFi.begin(STA_SSID, STA_PASSWORD);
    uint32_t t0 = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - t0 < STA_TIMEOUT_MS) {
      delay(250);
      Serial.print('.');
    }
    Serial.println();
    sta = WiFi.status() == WL_CONNECTED;
    if (sta) {
      Serial.printf("[WIFI] Συνδέθηκε. Άνοιξε: http://%s\n", WiFi.localIP().toString().c_str());
    } else {
      wl_status_t st = WiFi.status();
      const char *why =
        st == WL_NO_SSID_AVAIL  ? "δεν βρέθηκε το δίκτυο (5 GHz; λάθος όνομα; μακριά;)" :
        st == WL_CONNECT_FAILED ? "απορρίφθηκε η σύνδεση (λάθος κωδικός ή WPA3-only)" :
        st == WL_DISCONNECTED   ? "αποσυνδεδεμένο (συνήθως λάθος κωδικός ή αδύναμο σήμα)" :
                                  "άγνωστη αιτία";
      Serial.printf("[WIFI] Αποτυχία, κωδικός κατάστασης %d: %s\n", (int)st, why);
      // Διάγνωση: ποια δίκτυα 2.4 GHz βλέπει η πλακέτα;
      WiFi.disconnect(true);
      delay(100);
      int n = WiFi.scanNetworks();
      Serial.printf("[WIFI] Βλέπω %d δίκτυα 2.4 GHz:\n", n);
      bool seen = false;
      for (int i = 0; i < n; i++) {
        bool me = WiFi.SSID(i) == String(STA_SSID);
        seen |= me;
        Serial.printf("   %s \"%s\"  σήμα %d dBm  κανάλι %d  %s\n", me ? "→" : " ",
                      WiFi.SSID(i).c_str(), (int)WiFi.RSSI(i), (int)WiFi.channel(i),
                      WiFi.encryptionType(i) == WIFI_AUTH_WPA3_PSK ? "WPA3-only (ΔΕΝ υποστηρίζεται)" : "");
      }
      WiFi.scanDelete();
      if (!seen) Serial.printf("[WIFI] Το \"%s\" ΔΕΝ φαίνεται: είναι μόνο 5 GHz ή το όνομα διαφέρει (κεφαλαία/κενά).\n", STA_SSID);
      else       Serial.println("[WIFI] Το δίκτυο φαίνεται, άρα μάλλον φταίει ο κωδικός ή το σήμα (κάτω από -80 dBm είναι αδύναμο).");
      Serial.println("[WIFI] Γυρίζω σε Access Point");
    }
  }
  if (!sta) {
    WiFi.mode(WIFI_AP);
    WiFi.softAP(AP_SSID, AP_PASSWORD, AP_CHANNEL);
    Serial.printf("[WIFI] Access Point \"%s\" (κωδικός \"%s\")\n", AP_SSID, AP_PASSWORD);
    Serial.printf("[WIFI] Άνοιξε: http://%s\n", WiFi.softAPIP().toString().c_str());
  }
  WiFi.setSleep(false);   // μικρότερη καθυστέρηση στο joystick
}

void setup() {
  // 1) ΠΡΩΤΟ: IO12–IO15 έξοδοι LOW, για να μην κινηθούν τα μοτέρ στην εκκίνηση.
  motors::earlySafePins();
  pinMode(PIN_FLASH, OUTPUT);
  digitalWrite(PIN_FLASH, LOW);

  Serial.begin(115200);
  delay(50);
  Serial.println("\n=== Ρομπότ 4WD v1.5 ===");

  // 2) PWM μοτέρ και φωτός (κανάλια LEDC 2..6, μακριά από την κάμερα)
  motors::begin();
  light::begin();

  // 3) Κάμερα (LEDC timer 0 / channel 0 για το XCLK)
  if (!camera::begin()) Serial.println("[ΚΑΜΕΡΑ] Συνεχίζω χωρίς κάμερα");

  // 4) DFPlayer Pro (οι πρώτες εντολές φεύγουν αυτόματα μετά από ~1.5 s)
  audio::begin();

  // 5) Wi-Fi και servers
  startWifi();
  web::begin();

#if ENABLE_OTA
  if (esp_ota_get_next_update_partition(NULL) == NULL) {
    Serial.println("[OTA] ΠΡΟΣΟΧΗ: το Partition Scheme δεν έχει χώρο OTA.");
    Serial.println("[OTA] Διάλεξε \"Minimal SPIFFS (1.9MB APP with OTA)\" και ξανανέβασε με USB.");
  } else {
    ArduinoOTA.setHostname(HOSTNAME);
    ArduinoOTA.setPassword(OTA_PASSWORD);
    ArduinoOTA.onStart([]() {
      // Κατά την αναβάθμιση το loop() μπλοκάρει (και το failsafe μαζί), γι' αυτό:
      motors::lockOut();       // μοτέρ στο 0 και αγνόηση εντολών joystick
      light::set(false);
      light::update();
      web::stopStream();       // ελευθερώνει Wi-Fi/CPU από τη ροή κάμερας
      Serial.println("[OTA] Έναρξη ενημέρωσης");
    });
    ArduinoOTA.onError([](ota_error_t e) {
      // Μετά από αποτυχία τα μοτέρ είναι κλειδωμένα και η ροή σταματημένη:
      // επανεκκίνηση για να γυρίσει το ρομπότ σε κανονική λειτουργία.
      Serial.printf("[OTA] Σφάλμα %u – επανεκκίνηση\n", e);
      delay(200);
      ESP.restart();
    });
    ArduinoOTA.begin();
    s_otaReady = true;
  }
#endif
  Serial.println("[ΟΚ] Έτοιμο");
}

void loop() {
  motors::update();   // ράμπα + failsafe 500 ms
  light::update();
  audio::update();    // στέλνει τις εντολές AT από την ουρά
#if ENABLE_OTA
  if (s_otaReady) ArduinoOTA.handle();
#endif
  delay(2);
}
